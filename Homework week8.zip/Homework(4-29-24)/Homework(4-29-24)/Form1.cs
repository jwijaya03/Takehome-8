﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Homework_4_29_24_
{
    public partial class Form1 : Form
    {
        OpenFileDialog ofd = new OpenFileDialog();
        DataTable dt = new DataTable();
        int newQuantity = 1;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dt.Columns.Add("Item");
            dt.Columns.Add("Prize");
            dt.Columns.Add("Qty");
            dg_shoppingcart.DataSource = dt;
        }

        private void shirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            lb_item1.Text = "Black Shirt";
            lb_item2.Text = "Blue Shirt";
            lb_item3.Text = "Striped Shirt";
            lb_prize1.Text = "Rp.20000";
            lb_prize2.Text = "Rp.25000";
            lb_prize3.Text = "Rp.50000";
            pb_item1.Image = Image.FromFile("C:\\Users\\Jeff\\source\\repos\\Homework(4-29-24)\\Wardrobe\\Shirt\\Black_shirt.jpeg");
            pb_item2.Image = Image.FromFile("C:\\Users\\Jeff\\source\\repos\\Homework(4-29-24)\\Wardrobe\\Shirt\\Blue_Shirt.jpeg");
            pb_item3.Image = Image.FromFile("C:\\Users\\Jeff\\source\\repos\\Homework(4-29-24)\\Wardrobe\\Shirt\\Striped_Shirt.jpeg");
            gb_list.Visible = true;
            gb_custom.Visible = false;
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void tShirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            lb_item1.Text = "black T-Shirt";
            lb_item2.Text = "Blue T-Shirt";
            lb_item3.Text = "Logo T-shirt";
            lb_prize1.Text = "Rp.10000";
            lb_prize2.Text = "Rp.12000";
            lb_prize3.Text = "Rp.45000";
            pb_item1.Image = Image.FromFile("C:\\Users\\Jeff\\source\\repos\\Homework(4-29-24)\\Wardrobe\\T-Shirt\\tshirt_black.jpeg");
            pb_item2.Image = Image.FromFile("C:\\Users\\Jeff\\source\\repos\\Homework(4-29-24)\\Wardrobe\\T-Shirt\\tshirt_blue.jpeg");
            pb_item3.Image = Image.FromFile("C:\\Users\\Jeff\\source\\repos\\Homework(4-29-24)\\Wardrobe\\T-Shirt\\tshirt_logo.jpeg");
            gb_list.Visible = true;
            gb_custom.Visible = false;
        }

        private void pantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            lb_item1.Text = "Black Shorts";
            lb_item2.Text = "Blue Shorts";
            lb_item3.Text = "Grey Shorts";
            lb_prize1.Text = "Rp.25000";
            lb_prize2.Text = "Rp.30000";
            lb_prize3.Text = "Rp.30000";
            pb_item1.Image = Image.FromFile("C:\\Users\\Jeff\\source\\repos\\Homework(4-29-24)\\Wardrobe\\Pants\\black_shorts.jpeg");
            pb_item2.Image = Image.FromFile("C:\\Users\\Jeff\\source\\repos\\Homework(4-29-24)\\Wardrobe\\Pants\\blue_shorts.jpeg");
            pb_item3.Image = Image.FromFile("C:\\Users\\Jeff\\source\\repos\\Homework(4-29-24)\\Wardrobe\\Pants\\grey_shorts.jpeg");
            gb_list.Visible = true;
            gb_custom.Visible = false;
        }

        private void longPantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            lb_item1.Text = "Blue Pants";
            lb_item2.Text = "Cargo Pants";
            lb_item3.Text = "Grey Pants";
            lb_prize1.Text = "Rp.30000";
            lb_prize2.Text = "Rp.45000";
            lb_prize3.Text = "Rp.30000";
            pb_item1.Image = Image.FromFile("C:\\Users\\Jeff\\source\\repos\\Homework(4-29-24)\\Wardrobe\\Long_Pants\\blue_pants.jpeg");
            pb_item2.Image = Image.FromFile("C:\\Users\\Jeff\\source\\repos\\Homework(4-29-24)\\Wardrobe\\Long_Pants\\cargo_pants.jpeg");
            pb_item3.Image = Image.FromFile("C:\\Users\\Jeff\\source\\repos\\Homework(4-29-24)\\Wardrobe\\Long_Pants\\grey_pants.jpeg");
            gb_list.Visible = true;
            gb_custom.Visible = false;
        }

        private void shoesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            lb_item1.Text = "Black Shoe";
            lb_item2.Text = "White Shoe";
            lb_item3.Text = "Brown Loafer";
            lb_prize1.Text = "Rp.90000";
            lb_prize2.Text = "Rp.85000";
            lb_prize3.Text = "Rp.100000";
            pb_item1.Image = Image.FromFile("C:\\Users\\Jeff\\source\\repos\\Homework(4-29-24)\\Wardrobe\\Shoe\\black_shoe.jpeg");
            pb_item2.Image = Image.FromFile("C:\\Users\\Jeff\\source\\repos\\Homework(4-29-24)\\Wardrobe\\Shoe\\white_shoe.jpeg");
            pb_item3.Image = Image.FromFile("C:\\Users\\Jeff\\source\\repos\\Homework(4-29-24)\\Wardrobe\\Shoe\\brown_loafer.jpeg");
            gb_list.Visible = true;
            gb_custom.Visible = false;
        }

        private void jewelriesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            lb_item1.Text = "Pearl Necklace";
            lb_item2.Text = "Golden Earring";
            lb_item3.Text = "Diamond Ring";
            lb_prize1.Text = "Rp.750000";
            lb_prize2.Text = "Rp.600000";
            lb_prize3.Text = "Rp.1500000";
            pb_item1.Image = Image.FromFile("C:\\Users\\Jeff\\source\\repos\\Homework(4-29-24)\\Wardrobe\\Jewelry\\pearl_necklace.jpeg");
            pb_item2.Image = Image.FromFile("C:\\Users\\Jeff\\source\\repos\\Homework(4-29-24)\\Wardrobe\\Jewelry\\earring.jpeg");
            pb_item3.Image = Image.FromFile("C:\\Users\\Jeff\\source\\repos\\Homework(4-29-24)\\Wardrobe\\Jewelry\\diamond_ring.jpeg");
            gb_list.Visible = true;
            gb_custom.Visible = false;
        }

        private void otherToolStripMenuItem_Click(object sender, EventArgs e)
        {

            gb_list.Visible = false;
            gb_custom.Visible = true;
        }

        private void bt_additem1_Click(object sender, EventArgs e)
        {
            dt.Rows.Add(lb_item1.Text, lb_prize1);
            
        }
            

        private void bt_additem2_Click(object sender, EventArgs e)
        {
            dt.Rows.Add(lb_item2.Text, lb_prize2);
        }

        private void bt_additem3_Click(object sender, EventArgs e)
        {
            dt.Rows.Add(lb_item3.Text, lb_prize3);

        }

        private void dg_shoppingcart_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            ofd.Filter = "Jpeg(*.jpeg)|*.jpeg";
            ofd.InitialDirectory = "C:\\Wardrobe";
            ofd.ShowDialog();
            pb_custom.Image = Image.FromFile(ofd.FileName);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (pb_custom.Image == null && tb_itemname.Text == "" && tb_itemprize.Text == "")
            {
                MessageBox.Show("Can't Add Item");
            }
            else
            {
                gb_custom.Visible = true;
                dt.Rows.Add(tb_itemname.Text, tb_itemprize.Text);
            }
        }
    }
}
