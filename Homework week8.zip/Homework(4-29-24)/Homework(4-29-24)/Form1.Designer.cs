﻿namespace Homework_4_29_24_
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.topWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tShirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bottomWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.longPantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accesoriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shoesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jewelriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.otherToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.dg_shoppingcart = new System.Windows.Forms.DataGridView();
            this.lb_subtotal = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tb_subtotal = new System.Windows.Forms.TextBox();
            this.tb_total = new System.Windows.Forms.TextBox();
            this.pb_item1 = new System.Windows.Forms.PictureBox();
            this.gb_list = new System.Windows.Forms.GroupBox();
            this.bt_additem3 = new System.Windows.Forms.Button();
            this.bt_additem2 = new System.Windows.Forms.Button();
            this.bt_additem1 = new System.Windows.Forms.Button();
            this.lb_prize3 = new System.Windows.Forms.Label();
            this.lb_prize2 = new System.Windows.Forms.Label();
            this.lb_prize1 = new System.Windows.Forms.Label();
            this.lb_item3 = new System.Windows.Forms.Label();
            this.lb_item2 = new System.Windows.Forms.Label();
            this.lb_item1 = new System.Windows.Forms.Label();
            this.pb_item3 = new System.Windows.Forms.PictureBox();
            this.pb_item2 = new System.Windows.Forms.PictureBox();
            this.gb_custom = new System.Windows.Forms.GroupBox();
            this.bt_addcart = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tb_itemprize = new System.Windows.Forms.TextBox();
            this.tb_itemname = new System.Windows.Forms.TextBox();
            this.bt_upload = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.pb_custom = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg_shoppingcart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_item1)).BeginInit();
            this.gb_list.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_item3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_item2)).BeginInit();
            this.gb_custom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_custom)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.topWearToolStripMenuItem,
            this.bottomWearToolStripMenuItem,
            this.accesoriesToolStripMenuItem,
            this.otherToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(929, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // topWearToolStripMenuItem
            // 
            this.topWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tShirtToolStripMenuItem,
            this.shirtToolStripMenuItem});
            this.topWearToolStripMenuItem.Name = "topWearToolStripMenuItem";
            this.topWearToolStripMenuItem.Size = new System.Drawing.Size(86, 24);
            this.topWearToolStripMenuItem.Text = "Top Wear";
            // 
            // tShirtToolStripMenuItem
            // 
            this.tShirtToolStripMenuItem.Name = "tShirtToolStripMenuItem";
            this.tShirtToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.tShirtToolStripMenuItem.Text = "T-Shirt";
            this.tShirtToolStripMenuItem.Click += new System.EventHandler(this.tShirtToolStripMenuItem_Click);
            // 
            // shirtToolStripMenuItem
            // 
            this.shirtToolStripMenuItem.Name = "shirtToolStripMenuItem";
            this.shirtToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.shirtToolStripMenuItem.Text = "Shirt";
            this.shirtToolStripMenuItem.Click += new System.EventHandler(this.shirtToolStripMenuItem_Click);
            // 
            // bottomWearToolStripMenuItem
            // 
            this.bottomWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pantsToolStripMenuItem,
            this.longPantsToolStripMenuItem});
            this.bottomWearToolStripMenuItem.Name = "bottomWearToolStripMenuItem";
            this.bottomWearToolStripMenuItem.Size = new System.Drawing.Size(111, 24);
            this.bottomWearToolStripMenuItem.Text = "Bottom Wear";
            // 
            // pantsToolStripMenuItem
            // 
            this.pantsToolStripMenuItem.Name = "pantsToolStripMenuItem";
            this.pantsToolStripMenuItem.Size = new System.Drawing.Size(163, 26);
            this.pantsToolStripMenuItem.Text = "Pants";
            this.pantsToolStripMenuItem.Click += new System.EventHandler(this.pantsToolStripMenuItem_Click);
            // 
            // longPantsToolStripMenuItem
            // 
            this.longPantsToolStripMenuItem.Name = "longPantsToolStripMenuItem";
            this.longPantsToolStripMenuItem.Size = new System.Drawing.Size(163, 26);
            this.longPantsToolStripMenuItem.Text = "Long Pants";
            this.longPantsToolStripMenuItem.Click += new System.EventHandler(this.longPantsToolStripMenuItem_Click);
            // 
            // accesoriesToolStripMenuItem
            // 
            this.accesoriesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.shoesToolStripMenuItem,
            this.jewelriesToolStripMenuItem});
            this.accesoriesToolStripMenuItem.Name = "accesoriesToolStripMenuItem";
            this.accesoriesToolStripMenuItem.Size = new System.Drawing.Size(93, 24);
            this.accesoriesToolStripMenuItem.Text = "Accesories";
            // 
            // shoesToolStripMenuItem
            // 
            this.shoesToolStripMenuItem.Name = "shoesToolStripMenuItem";
            this.shoesToolStripMenuItem.Size = new System.Drawing.Size(151, 26);
            this.shoesToolStripMenuItem.Text = "Shoes";
            this.shoesToolStripMenuItem.Click += new System.EventHandler(this.shoesToolStripMenuItem_Click);
            // 
            // jewelriesToolStripMenuItem
            // 
            this.jewelriesToolStripMenuItem.Name = "jewelriesToolStripMenuItem";
            this.jewelriesToolStripMenuItem.Size = new System.Drawing.Size(151, 26);
            this.jewelriesToolStripMenuItem.Text = "Jewelries";
            this.jewelriesToolStripMenuItem.Click += new System.EventHandler(this.jewelriesToolStripMenuItem_Click);
            // 
            // otherToolStripMenuItem
            // 
            this.otherToolStripMenuItem.Name = "otherToolStripMenuItem";
            this.otherToolStripMenuItem.Size = new System.Drawing.Size(60, 24);
            this.otherToolStripMenuItem.Text = "Other";
            this.otherToolStripMenuItem.Click += new System.EventHandler(this.otherToolStripMenuItem_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // dg_shoppingcart
            // 
            this.dg_shoppingcart.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_shoppingcart.Location = new System.Drawing.Point(529, 31);
            this.dg_shoppingcart.Name = "dg_shoppingcart";
            this.dg_shoppingcart.RowHeadersWidth = 51;
            this.dg_shoppingcart.RowTemplate.Height = 24;
            this.dg_shoppingcart.Size = new System.Drawing.Size(248, 174);
            this.dg_shoppingcart.TabIndex = 2;
            this.dg_shoppingcart.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dg_shoppingcart_CellContentClick);
            // 
            // lb_subtotal
            // 
            this.lb_subtotal.AutoSize = true;
            this.lb_subtotal.Location = new System.Drawing.Point(526, 230);
            this.lb_subtotal.Name = "lb_subtotal";
            this.lb_subtotal.Size = new System.Drawing.Size(66, 16);
            this.lb_subtotal.TabIndex = 3;
            this.lb_subtotal.Text = "Sub-Total";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(526, 260);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 16);
            this.label1.TabIndex = 4;
            this.label1.Text = "Total";
            // 
            // tb_subtotal
            // 
            this.tb_subtotal.Location = new System.Drawing.Point(612, 230);
            this.tb_subtotal.Name = "tb_subtotal";
            this.tb_subtotal.Size = new System.Drawing.Size(100, 22);
            this.tb_subtotal.TabIndex = 5;
            // 
            // tb_total
            // 
            this.tb_total.Location = new System.Drawing.Point(612, 260);
            this.tb_total.Name = "tb_total";
            this.tb_total.Size = new System.Drawing.Size(100, 22);
            this.tb_total.TabIndex = 6;
            // 
            // pb_item1
            // 
            this.pb_item1.Location = new System.Drawing.Point(6, 21);
            this.pb_item1.Name = "pb_item1";
            this.pb_item1.Size = new System.Drawing.Size(110, 152);
            this.pb_item1.TabIndex = 7;
            this.pb_item1.TabStop = false;
            // 
            // gb_list
            // 
            this.gb_list.Controls.Add(this.bt_additem3);
            this.gb_list.Controls.Add(this.bt_additem2);
            this.gb_list.Controls.Add(this.bt_additem1);
            this.gb_list.Controls.Add(this.lb_prize3);
            this.gb_list.Controls.Add(this.lb_prize2);
            this.gb_list.Controls.Add(this.lb_prize1);
            this.gb_list.Controls.Add(this.lb_item3);
            this.gb_list.Controls.Add(this.lb_item2);
            this.gb_list.Controls.Add(this.lb_item1);
            this.gb_list.Controls.Add(this.pb_item3);
            this.gb_list.Controls.Add(this.pb_item2);
            this.gb_list.Controls.Add(this.pb_item1);
            this.gb_list.Location = new System.Drawing.Point(12, 35);
            this.gb_list.Name = "gb_list";
            this.gb_list.Size = new System.Drawing.Size(387, 284);
            this.gb_list.TabIndex = 8;
            this.gb_list.TabStop = false;
            this.gb_list.Visible = false;
            // 
            // bt_additem3
            // 
            this.bt_additem3.Location = new System.Drawing.Point(259, 242);
            this.bt_additem3.Name = "bt_additem3";
            this.bt_additem3.Size = new System.Drawing.Size(94, 23);
            this.bt_additem3.TabIndex = 18;
            this.bt_additem3.Text = "Add To Cart";
            this.bt_additem3.UseVisualStyleBackColor = true;
            this.bt_additem3.Click += new System.EventHandler(this.bt_additem3_Click);
            // 
            // bt_additem2
            // 
            this.bt_additem2.Location = new System.Drawing.Point(134, 242);
            this.bt_additem2.Name = "bt_additem2";
            this.bt_additem2.Size = new System.Drawing.Size(94, 23);
            this.bt_additem2.TabIndex = 17;
            this.bt_additem2.Text = "Add To Cart";
            this.bt_additem2.UseVisualStyleBackColor = true;
            this.bt_additem2.Click += new System.EventHandler(this.bt_additem2_Click);
            // 
            // bt_additem1
            // 
            this.bt_additem1.Location = new System.Drawing.Point(6, 242);
            this.bt_additem1.Name = "bt_additem1";
            this.bt_additem1.Size = new System.Drawing.Size(94, 23);
            this.bt_additem1.TabIndex = 16;
            this.bt_additem1.Text = "Add To Cart";
            this.bt_additem1.UseVisualStyleBackColor = true;
            this.bt_additem1.Click += new System.EventHandler(this.bt_additem1_Click);
            // 
            // lb_prize3
            // 
            this.lb_prize3.AutoSize = true;
            this.lb_prize3.Location = new System.Drawing.Point(274, 214);
            this.lb_prize3.Name = "lb_prize3";
            this.lb_prize3.Size = new System.Drawing.Size(35, 16);
            this.lb_prize3.TabIndex = 15;
            this.lb_prize3.Text = "Rp.0";
            // 
            // lb_prize2
            // 
            this.lb_prize2.AutoSize = true;
            this.lb_prize2.Location = new System.Drawing.Point(146, 214);
            this.lb_prize2.Name = "lb_prize2";
            this.lb_prize2.Size = new System.Drawing.Size(35, 16);
            this.lb_prize2.TabIndex = 14;
            this.lb_prize2.Text = "Rp.0";
            this.lb_prize2.Click += new System.EventHandler(this.label7_Click);
            // 
            // lb_prize1
            // 
            this.lb_prize1.AutoSize = true;
            this.lb_prize1.Location = new System.Drawing.Point(19, 214);
            this.lb_prize1.Name = "lb_prize1";
            this.lb_prize1.Size = new System.Drawing.Size(35, 16);
            this.lb_prize1.TabIndex = 13;
            this.lb_prize1.Text = "Rp.0";
            // 
            // lb_item3
            // 
            this.lb_item3.AutoSize = true;
            this.lb_item3.Location = new System.Drawing.Point(274, 185);
            this.lb_item3.Name = "lb_item3";
            this.lb_item3.Size = new System.Drawing.Size(42, 16);
            this.lb_item3.TabIndex = 12;
            this.lb_item3.Text = "Item 3";
            // 
            // lb_item2
            // 
            this.lb_item2.AutoSize = true;
            this.lb_item2.Location = new System.Drawing.Point(139, 185);
            this.lb_item2.Name = "lb_item2";
            this.lb_item2.Size = new System.Drawing.Size(42, 16);
            this.lb_item2.TabIndex = 11;
            this.lb_item2.Text = "Item 2";
            // 
            // lb_item1
            // 
            this.lb_item1.AutoSize = true;
            this.lb_item1.Location = new System.Drawing.Point(19, 185);
            this.lb_item1.Name = "lb_item1";
            this.lb_item1.Size = new System.Drawing.Size(42, 16);
            this.lb_item1.TabIndex = 10;
            this.lb_item1.Text = "Item 1";
            // 
            // pb_item3
            // 
            this.pb_item3.Location = new System.Drawing.Point(259, 21);
            this.pb_item3.Name = "pb_item3";
            this.pb_item3.Size = new System.Drawing.Size(110, 152);
            this.pb_item3.TabIndex = 9;
            this.pb_item3.TabStop = false;
            // 
            // pb_item2
            // 
            this.pb_item2.Location = new System.Drawing.Point(134, 21);
            this.pb_item2.Name = "pb_item2";
            this.pb_item2.Size = new System.Drawing.Size(110, 152);
            this.pb_item2.TabIndex = 8;
            this.pb_item2.TabStop = false;
            // 
            // gb_custom
            // 
            this.gb_custom.Controls.Add(this.bt_addcart);
            this.gb_custom.Controls.Add(this.label4);
            this.gb_custom.Controls.Add(this.label3);
            this.gb_custom.Controls.Add(this.tb_itemprize);
            this.gb_custom.Controls.Add(this.tb_itemname);
            this.gb_custom.Controls.Add(this.bt_upload);
            this.gb_custom.Controls.Add(this.label2);
            this.gb_custom.Controls.Add(this.pb_custom);
            this.gb_custom.Location = new System.Drawing.Point(12, 31);
            this.gb_custom.Name = "gb_custom";
            this.gb_custom.Size = new System.Drawing.Size(295, 276);
            this.gb_custom.TabIndex = 9;
            this.gb_custom.TabStop = false;
            this.gb_custom.Visible = false;
            // 
            // bt_addcart
            // 
            this.bt_addcart.Location = new System.Drawing.Point(157, 206);
            this.bt_addcart.Name = "bt_addcart";
            this.bt_addcart.Size = new System.Drawing.Size(94, 23);
            this.bt_addcart.TabIndex = 21;
            this.bt_addcart.Text = "Add to Cart";
            this.bt_addcart.UseVisualStyleBackColor = true;
            this.bt_addcart.Click += new System.EventHandler(this.button2_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(146, 134);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 16);
            this.label4.TabIndex = 20;
            this.label4.Text = "Item Prize:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(146, 80);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 16);
            this.label3.TabIndex = 10;
            this.label3.Text = "Item Name:";
            // 
            // tb_itemprize
            // 
            this.tb_itemprize.Location = new System.Drawing.Point(146, 157);
            this.tb_itemprize.Name = "tb_itemprize";
            this.tb_itemprize.Size = new System.Drawing.Size(100, 22);
            this.tb_itemprize.TabIndex = 10;
            // 
            // tb_itemname
            // 
            this.tb_itemname.Location = new System.Drawing.Point(146, 103);
            this.tb_itemname.Name = "tb_itemname";
            this.tb_itemname.Size = new System.Drawing.Size(100, 22);
            this.tb_itemname.TabIndex = 10;
            // 
            // bt_upload
            // 
            this.bt_upload.Location = new System.Drawing.Point(126, 33);
            this.bt_upload.Name = "bt_upload";
            this.bt_upload.Size = new System.Drawing.Size(94, 23);
            this.bt_upload.TabIndex = 19;
            this.bt_upload.Text = "Upload";
            this.bt_upload.UseVisualStyleBackColor = true;
            this.bt_upload.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(27, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 16);
            this.label2.TabIndex = 19;
            this.label2.Text = "Upload Image";
            // 
            // pb_custom
            // 
            this.pb_custom.Location = new System.Drawing.Point(30, 77);
            this.pb_custom.Name = "pb_custom";
            this.pb_custom.Size = new System.Drawing.Size(110, 152);
            this.pb_custom.TabIndex = 19;
            this.pb_custom.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(929, 439);
            this.Controls.Add(this.gb_custom);
            this.Controls.Add(this.gb_list);
            this.Controls.Add(this.tb_total);
            this.Controls.Add(this.tb_subtotal);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lb_subtotal);
            this.Controls.Add(this.dg_shoppingcart);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg_shoppingcart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_item1)).EndInit();
            this.gb_list.ResumeLayout(false);
            this.gb_list.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_item3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_item2)).EndInit();
            this.gb_custom.ResumeLayout(false);
            this.gb_custom.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_custom)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem topWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tShirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bottomWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem longPantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accesoriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shoesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jewelriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem otherToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.DataGridView dg_shoppingcart;
        private System.Windows.Forms.Label lb_subtotal;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tb_subtotal;
        private System.Windows.Forms.TextBox tb_total;
        private System.Windows.Forms.PictureBox pb_item1;
        private System.Windows.Forms.GroupBox gb_list;
        private System.Windows.Forms.Button bt_additem3;
        private System.Windows.Forms.Button bt_additem2;
        private System.Windows.Forms.Button bt_additem1;
        private System.Windows.Forms.Label lb_prize3;
        private System.Windows.Forms.Label lb_prize2;
        private System.Windows.Forms.Label lb_prize1;
        private System.Windows.Forms.Label lb_item3;
        private System.Windows.Forms.Label lb_item2;
        private System.Windows.Forms.Label lb_item1;
        private System.Windows.Forms.PictureBox pb_item3;
        private System.Windows.Forms.PictureBox pb_item2;
        private System.Windows.Forms.GroupBox gb_custom;
        private System.Windows.Forms.Button bt_addcart;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb_itemprize;
        private System.Windows.Forms.TextBox tb_itemname;
        private System.Windows.Forms.Button bt_upload;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pb_custom;
    }
}

